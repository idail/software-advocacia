# Adminmart-lite
Build Web Application or Dashboard Faster with AdminMart Free Bootstrap5 Admin theme built with html/css, ready to use for your next project.
<h2><a href="https://demos.adminmart.com/free/bootstrap/freedash-lite/src/html/index.html" >Live Demo</a></h2>
